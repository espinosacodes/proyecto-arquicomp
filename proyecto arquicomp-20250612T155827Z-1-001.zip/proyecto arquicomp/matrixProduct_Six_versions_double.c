#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>

// Adaptado de https://inst.eecs.berkeley.edu/~cs61c/fa12/labs/07/
// Implementación en C++ para double (64 bits), con las 6 variantes del orden de bucles.

void ProductMat_a(int n, double* A, double* B, double* C) {
    int i, j, k;
    double sum;
    /* This is ijk loop order version. */
    for (i = 0; i < n; i++) {
        for (j = 0; j < n; j++) {
            sum = 0;
            for (k = 0; k < n; k++) {
                sum += A[i + k * n] * B[k + j * n]; // C[i][j] += A[i][k] * B[k][j]
            }
            C[i + j * n] += sum;
        }
    }
}

void ProductMat_b(int n, double* A, double* B, double* C) {
    int i, j, k;
    double sum;
    /* This is jik loop order version. */
    for (j = 0; j < n; j++) {
        for (i = 0; i < n; i++) {
            sum = 0;
            for (k = 0; k < n; k++) {
                sum += A[i + k * n] * B[k + j * n];
            }
            C[i + j * n] += sum;
        }
    }
}

void ProductMat_c(int n, double* A, double* B, double* C) {
    int i, j, k;
    double r;
    /* This is jki loop order version. */
    for (j = 0; j < n; j++) {
        for (k = 0; k < n; k++) {
            r = B[k + j * n];
            for (i = 0; i < n; i++) {
                C[i + j * n] += A[i + k * n] * r;
            }
        }
    }
}

void ProductMat_d(int n, double* A, double* B, double* C) {
    int i, j, k;
    double r;
    /* This is kji loop order. */
    for (k = 0; k < n; k++) {
        for (j = 0; j < n; j++) {
            r = B[k + j * n];
            for (i = 0; i < n; i++) {
                C[i + j * n] += A[i + k * n] * r;
            }
        }
    }
}

void ProductMat_e(int n, double* A, double* B, double* C) {
    int i, j, k;
    double r;
    /* This is kij loop order version. */
    for (k = 0; k < n; k++) {
        for (i = 0; i < n; i++) {
            r = A[i + k * n];
            for (j = 0; j < n; j++) {
                C[i + j * n] += r * B[k + j * n];
            }
        }
    }
}

void ProductMat_f(int n, double* A, double* B, double* C) {
    int i, j, k;
    double r;
    /* This is ikj loop order version. */
    for (i = 0; i < n; i++) {
        for (k = 0; k < n; k++) {
            r = A[i + k * n];
            for (j = 0; j < n; j++) {
                C[i + j * n] += r * B[k + j * n];
            }
        }
    }
}

// Función para imprimir matrices
void PrintMat(int n, double* M) {
    int i, j;
    for (j = 0; j < n; j++) {
        for (i = 0; i < n; i++) {
            printf("%.3f ", M[i + j * n]);
        }
        printf(";\n");
    }
    printf("\n\n");
}

// Variable global para el archivo
FILE* fp;

int main(int argc, char* argv[]) {
    errno_t err;
    err = fopen_s(&fp, "ReportS2_LHW00.txt", "a+");
    if (err != 0) {
        printf("The file .txt was not opened\n");
        return 0;
    }

    if (argc < 3) {
        printf("Uso: <programa> <n> <samples>\n");
        fclose(fp);
        return 0;
    }

    int n = atoi(argv[1]); // Tamaño de la matriz
    int samples = atoi(argv[2]); // Número de muestras

    // Asignación de memoria para matrices con double
    double* A = (double*)malloc(n * n * sizeof(double));
    double* B = (double*)malloc(n * n * sizeof(double));
    double* C = (double*)malloc(n * n * sizeof(double));

    // Inicialización de matrices
    for (int i = 0; i < n * n; i++) A[i] = 2.0;
    for (int i = 0; i < n * n; i++) B[i] = 4.0;
    for (int i = 0; i < n * n; i++) C[i] = 0.0;

    printf("ver\ttypeData\tISA\t#sample\tn\ttime(s)\tNormalized(ns)\n");
    for (int s = 0; s < samples; s++) {
        for (int i = 0; i < n * n; i++) C[i] = 0.0;

        clock_t start = clock(); // Inicio de medición
        ProductMat_f(n, A, B, C); // Usamos versión f como ejemplo
        clock_t end = clock();   // Fin de medición

        double seconds = (double)(end - start) / CLOCKS_PER_SEC;
        double N = n;
        double timeNormalized = (seconds * 1.0e9) / (N * N * N); // ns

        printf("C++ver(f)\tdouble\tx64\t%03d\t%05d\t%.4f\t%.4f\n", s, n, seconds, timeNormalized);
        fprintf_s(fp, "C++ver(f)\tdouble\tx64\t%03d\t%05d\t%.4f\t%.4f\n", s, n, seconds, timeNormalized);
    }

    // Imprimir matrices si hay un tercer argumento
    if (argc > 3) {
        PrintMat(n, A);
        PrintMat(n, B);
        PrintMat(n, C);
    }

    // Liberar memoria y cerrar archivo
    free(A);
    free(B);
    free(C);
    fclose(fp);
    printf("\n");
    return 0;
}